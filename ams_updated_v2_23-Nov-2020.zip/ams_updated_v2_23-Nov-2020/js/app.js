var category = $("#category");
category.on("input", () => {
  var software = $("#software");
  var plant = $("#plant");
  var vehicle = $("#vehicle");
  var furniture = $("#furniture");
  var building = $("#building");
  var office = $("#office");
  if (category.val() === "") {
    plant.attr("hidden", true);
    software.attr("hidden", true);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", true);
    building.attr("hidden", true);
    office.attr("hidden", true);
  } else if (category.val() === "software") {
    plant.attr("hidden", true);
    software.attr("hidden", false);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", true);
    building.attr("hidden", true);
    office.attr("hidden", true);
  } else if (category.val() === "plant") {
    plant.attr("hidden", false);
    software.attr("hidden", true);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", true);
    building.attr("hidden", true);
    office.attr("hidden", true);
  } else if (category.val() === "vehicle") {
    plant.attr("hidden", true);
    software.attr("hidden", true);
    vehicle.attr("hidden", false);
    furniture.attr("hidden", true);
    building.attr("hidden", true);
    office.attr("hidden", true);
  } else if (category.val() === "furniture") {
    plant.attr("hidden", true);
    software.attr("hidden", true);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", false);
    building.attr("hidden", true);
    office.attr("hidden", true);
  } else if (category.val() === "building") {
    plant.attr("hidden", true);
    software.attr("hidden", true);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", true);
    building.attr("hidden", false);
    office.attr("hidden", true);
  } else if (category.val() === "office") {
    plant.attr("hidden", true);
    software.attr("hidden", true);
    vehicle.attr("hidden", true);
    furniture.attr("hidden", true);
    building.attr("hidden", true);
    office.attr("hidden", false);
  }
});
